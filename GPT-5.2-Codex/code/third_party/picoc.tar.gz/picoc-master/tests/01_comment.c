#include <stdio.h>

printf("Hello\n");
printf("Hello\n"); /* this is a comment */ printf("Hello\n");
printf("Hello\n");
// this is also a comment sayhello();
printf("Hello\n");


void main() {}
