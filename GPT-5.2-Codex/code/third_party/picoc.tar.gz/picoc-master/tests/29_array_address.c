#include <stdio.h>
#include <string.h>

char a[10];
strcpy(a, "abcdef");
printf("%s\n", &a[1]);

void main() {}
