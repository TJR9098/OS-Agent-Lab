#include <stdio.h>

void fred(void)
{
    printf("yo\n");
}

fred();

void main() {}
