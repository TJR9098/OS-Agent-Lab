#include <stdio.h>

int a;
a = 42;
printf("%d\n", a);

int b = 64;
printf("%d\n", b);

int c = 12, d = 34;
printf("%d, %d\n", c, d);

void main() {}
