#include <stdio.h>

int Count;

for (Count = 1; Count <= 10; Count++)
{
    printf("%d\n", Count);
}

void main() {}
