#include <stdio.h>

printf("including\n");
#include "18_include.h"
printf("done\n");

void main() {}
