
double add(int a, float b) {
  return a + b;
}

int main() {
printf("hello world %d \n", add(1+2));
return 0;
}
