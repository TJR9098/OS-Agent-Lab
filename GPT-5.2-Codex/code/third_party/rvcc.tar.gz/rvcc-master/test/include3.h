// [184] 支持 #include <...>
#define foo 3
