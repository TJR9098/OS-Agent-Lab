#include "test.h"
#include <float.h>
#include <stdalign.h>
#include <stdarg.h>
#include <stdbool.h>
#include <stddef.h>
#include <stdnoreturn.h>

int main() {
  // [195] 支持多个头文件
  printf("OK\n");
  return 0;
}
