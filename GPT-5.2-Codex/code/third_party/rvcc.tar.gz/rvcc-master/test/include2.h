// [160] 支持 #include "..."
int include2 = 7;
